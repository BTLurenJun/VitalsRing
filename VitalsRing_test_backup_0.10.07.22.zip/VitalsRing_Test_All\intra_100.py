# -*- coding: utf-8 -*-
"""VitalsRing 100 轮进程内自动压力测试（一次性）。

唯一循环是 100 轮 for；无 while、无轮询、无自动重跑。
只在本进程内驱动 VitalsRing，用 QScreen 截图，不移动真实鼠标/键盘。
"""

import csv
import os
import platform
import random
import sys
import time
import traceback

PROJECT_DIR = r"d:\trae_projects\VitalsRing\VitalsRing"
TEST_DIR = r"D:\VitalsRing_Test_All"
SHOTS_DIR = os.path.join(TEST_DIR, "shots")
FAIL_DIR = os.path.join(TEST_DIR, "failures")

sys.path.insert(0, PROJECT_DIR)
os.chdir(PROJECT_DIR)

from PyQt6.QtCore import QPoint
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication

import main as app_main
from readers import SystemReader

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

WAITS = [0, 10, 20, 40, 80, 160]

SCENARIOS = [
    "设置窗口开/关",
    "调试模式开关快速连点",
    "调试卡展开动画中途关闭设置窗口",
    "挂件/大面板模式快速切换",
    "5 个槽位下拉随机改 1~3 次后恢复默认",
    "图标风格/拟物化图标/显示刻度切换",
    "CPU/GPU/内存/C盘/电池检测随机关开",
    "设置锁开/关，锁上后改一项配置再解锁",
    "恢复默认设置",
    "详情窗口开/关、设置窗口重开",
]

app = None
reader = None
panel = None
round_rows = []
log_lines = []
stop_reason = ""
consecutive_error = 0


def wait(ms: int) -> None:
    if ms and ms > 0:
        QTest.qWait(int(ms))
    else:
        QApplication.processEvents()


def current_settings():
    return getattr(panel, "_settings", None) if panel is not None else None


def open_settings() -> None:
    panel._open_settings()
    QApplication.processEvents()


def close_settings() -> None:
    sw = current_settings()
    if sw is not None and sw.isVisible():
        sw.close()
        QApplication.processEvents()


def detail_visible() -> bool:
    detail = getattr(panel, "_detail", None)
    try:
        return bool(detail is not None and detail.isVisible())
    except Exception:
        return False


def capture_widget(widget, path: str):
    """QScreen 截图后按窗口矩形裁剪；失败退回 widget.grab()。"""
    try:
        screen = widget.screen() or QGuiApplication.primaryScreen()
        if screen is None:
            raise RuntimeError("no screen")
        full = screen.grabWindow(0)
        if full.isNull():
            raise RuntimeError("grab null")
        dpr = float(full.devicePixelRatio()) or 1.0
        geo = screen.geometry()
        top_left = widget.mapToGlobal(QPoint(0, 0))
        rx = int(round((top_left.x() - geo.x()) * dpr))
        ry = int(round((top_left.y() - geo.y()) * dpr))
        rw = max(1, int(round(widget.width() * dpr)))
        rh = max(1, int(round(widget.height() * dpr)))
        pix = full.copy(rx, ry, rw, rh)
        if pix.isNull():
            raise RuntimeError("crop null")
        pix.save(path, "PNG")
        return path
    except Exception:
        try:
            widget.grab().save(path, "PNG")
            return path
        except Exception:
            return None


class Ctx:
    """一轮的步骤记录器；每步后按轮换档位等待，并顺手观测设置窗口滚动范围。"""

    def __init__(self, round_no: int) -> None:
        self.round_no = round_no
        self.step_index = 0
        self.ops = []
        self.scroll_max = -1
        self.settings_seen = False

    def observe(self) -> None:
        try:
            sw = current_settings()
            if sw is not None and sw.isVisible():
                self.settings_seen = True
                value = int(sw._scroll.verticalScrollBar().maximum())
                self.scroll_max = max(self.scroll_max, value)
        except Exception:
            pass

    def st(self, name: str, fn) -> None:
        fn()
        wait(WAITS[(self.round_no + self.step_index) % len(WAITS)])
        self.ops.append(name)
        self.step_index += 1
        self.observe()


def snapshot_state(cx: Ctx) -> dict:
    sw = current_settings()
    try:
        settings_visible = bool(sw is not None and sw.isVisible())
    except Exception:
        settings_visible = False
    try:
        scroll_max = int(sw._scroll.verticalScrollBar().maximum()) if settings_visible else -1
    except Exception:
        scroll_max = -1
    if scroll_max < 0:
        scroll_max = cx.scroll_max
    try:
        slots = "|".join(panel.slot_keys())
    except Exception:
        slots = ""
    return {
        "layout_mode": panel.layout_mode(),
        "debug_active": int(bool(getattr(reader, "debug_active", False))),
        "lock_state": int(bool(panel.settings_locked())),
        "slot_keys": slots,
        "settings_visible": int(settings_visible),
        "detail_visible": int(detail_visible()),
        "scroll_max": scroll_max,
    }


def pick_slot_change(rnd: random.Random) -> bool:
    sw = current_settings()
    if sw is None or not sw._slot_combos:
        return False
    combos = sw._slot_combos
    index = rnd.randrange(len(combos))
    current = [combo.currentData() for combo in combos]
    used_by_others = set(current)
    used_by_others.discard(current[index])
    available = [key for key, _label in panel.available_slot_items()
                 if key not in used_by_others]
    if not available:
        return False
    key = available[rnd.randrange(len(available))]
    pos = combos[index].findData(key)
    if pos < 0:
        return False
    combos[index].setCurrentIndex(pos)
    return True


def detect_keys_for(round_no: int):
    rnd = random.Random(round_no)
    return rnd.sample(["cpu", "gpu", "mem", "disk_c", "battery"], 2)


def sc_settings_open_close(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    cx.st("settings_sync_ui", lambda: sw and sw.sync_show_ticks())
    cx.st("close_settings", close_settings)
    cx.st("verify_closed", lambda: None)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    if sw.isVisible():
        return False, "close() 后设置窗口仍然可见"
    return True, ""


def sc_debug_rapid(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    cx.st("debug_on_1", lambda: sw._debug_check.setChecked(True))
    cx.st("debug_off_1", lambda: sw._debug_check.setChecked(False))
    cx.st("debug_on_2", lambda: sw._debug_check.setChecked(True))
    cx.st("debug_off_2", lambda: sw._debug_check.setChecked(False))
    cx.st("close_settings", close_settings)
    if reader.debug_active:
        return False, "关闭设置后 debug_active 仍为 True"
    return True, ""


def sc_close_mid_animation(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    cx.st("debug_on", lambda: sw._debug_check.setChecked(True))
    cx.st("close_mid_anim", close_settings)
    wait(400)
    if reader.debug_active:
        return False, "动画中途关闭后 debug_active 仍为 True"
    if bool(getattr(sw, "_rows_expanded", False)):
        return False, "动画中途关闭后调试卡仍处于展开标志位"
    if int(getattr(sw, "_rows_box", sw).maximumHeight()) != 0:
        return False, "动画中途关闭后调试卡最大高度不为 0"
    return True, ""


def sc_mode_switch(cx: Ctx):
    cx.st("to_panel_1", lambda: panel.set_layout_mode("panel"))
    cx.st("to_widget_1", lambda: panel.set_layout_mode("widget"))
    cx.st("to_panel_2", lambda: panel.set_layout_mode("panel"))
    cx.st("to_widget_2", lambda: panel.set_layout_mode("widget"))
    if panel.layout_mode() != "widget":
        return False, "连续切换后未回到 widget 模式"
    if bool(getattr(panel, "_switching_mode", False)):
        return False, "切换结束后 _switching_mode 仍为 True"
    return True, ""


def sc_slot_dropdowns(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    rnd = random.Random(cx.round_no * 7919)
    times = rnd.randint(1, 3)
    for i in range(times):
        cx.st(f"slot_change_{i + 1}", lambda r=rnd: pick_slot_change(r))
    cx.st("reset_slots", lambda: sw._on_reset_slots())
    cx.st("close_settings", close_settings)
    if panel.slot_keys() != panel.default_slot_keys():
        return False, "恢复默认后槽位不等于默认配置"
    return True, ""


def sc_icon_and_ticks(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"

    def set_style_line():
        idx = sw._icon_style_combo.findData("line")
        if idx >= 0:
            sw._icon_style_combo.setCurrentIndex(idx)

    cx.st("style_line", set_style_line)
    cx.st("icon_off", lambda: sw._icon_style_check.setChecked(False))
    cx.st("ticks_on", lambda: sw._show_ticks_check.setChecked(True))
    cx.st("style_color", lambda: sw._icon_style_combo.setCurrentIndex(
        max(0, sw._icon_style_combo.findData("color"))))
    cx.st("close_settings", close_settings)
    if panel.icon_style() != "color":
        return False, "关闭后图标风格不是 color"
    if not panel.show_ticks_enabled():
        return False, "勾选刻度后未生效"
    if panel.use_icon_style_enabled():
        return False, "取消拟物化图标后仍为开启"
    return True, ""


def sc_detect_toggles(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    keys = detect_keys_for(cx.round_no)
    cx.st("detect_off_1", lambda: sw._detect_checks[keys[0]].setChecked(False))
    cx.st("detect_off_2", lambda: sw._detect_checks[keys[1]].setChecked(False))
    cx.st("detect_on_1", lambda: sw._detect_checks[keys[0]].setChecked(True))
    cx.st("detect_on_2", lambda: sw._detect_checks[keys[1]].setChecked(True))
    cx.st("close_settings", close_settings)
    if not all(bool(reader.enabled.get(k, True)) for k in keys):
        return False, "检测开关回开后状态仍为关闭"
    return True, ""


def sc_lock_cycle(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    cx.st("lock_on", sw._on_lock_clicked)
    if not panel.settings_locked():
        return False, "点击锁定后 lock_state 仍为 False"
    cx.st("change_ticks_locked", lambda: sw._show_ticks_check.setChecked(True))
    cx.st("lock_off", sw._on_lock_clicked)
    cx.st("close_settings", close_settings)
    if panel.settings_locked():
        return False, "解锁后 lock_state 仍为 True"
    return True, ""


def sc_reset_defaults(cx: Ctx):
    cx.st("open_settings", open_settings)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建"
    cx.st("reset_all", sw._on_reset_all)
    wait(700)
    cx.st("close_settings", close_settings)
    if panel.layout_mode() != "widget":
        return False, "恢复默认后不是挂件模式"
    if panel.show_ticks_enabled():
        return False, "恢复默认后刻度仍开启"
    if panel.slot_keys() != panel.default_slot_keys():
        return False, "恢复默认后槽位不是默认配置"
    if panel.settings_locked():
        return False, "恢复默认后设置仍处于锁定"
    if not panel.use_icon_style_enabled() or panel.icon_style() != "color":
        return False, "恢复默认后图标状态不是默认值"
    return True, ""


def sc_detail_and_settings(cx: Ctx):
    cx.st("detail_toggle_open", panel._toggle_detail)
    if not detail_visible():
        return False, "第一次点击后详情窗口未显示"
    cx.st("detail_toggle_close", panel._toggle_detail)
    if detail_visible():
        return False, "第二次点击后详情窗口仍显示"
    cx.st("settings_reopen", open_settings)
    sw = current_settings()
    if sw is None or not sw.isVisible():
        return False, "设置窗口未能重新打开"
    cx.st("settings_close", close_settings)
    cx.st("detail_again_open", panel._toggle_detail)
    cx.st("detail_again_close", panel._toggle_detail)
    if detail_visible():
        return False, "收尾后详情窗口仍显示"
    return True, ""


SCENARIO_FUNCS = [
    sc_settings_open_close,
    sc_debug_rapid,
    sc_close_mid_animation,
    sc_mode_switch,
    sc_slot_dropdowns,
    sc_icon_and_ticks,
    sc_detect_toggles,
    sc_lock_cycle,
    sc_reset_defaults,
    sc_detail_and_settings,
]


def reset_round() -> None:
    try:
        if panel.settings_locked():
            panel.set_settings_locked(False)
        sw = current_settings()
        if sw is not None and sw.isVisible():
            sw.close()
        wait(150)
        panel._close_detail()
        if panel.layout_mode() != "widget":
            panel.set_layout_mode("widget")
        if getattr(reader, "debug_active", False):
            reader.debug_active = False
            reader.debug_values.clear()
            reader.apply_state()
            panel.resume_refresh()
        panel.set_slot_config(panel.default_slot_keys())
        panel.set_show_ticks(False)
        panel.set_use_icon_style(True)
        panel.set_icon_style("color")
        for key in list(reader.enabled.keys()):
            reader.enabled[key] = True
        reader.apply_state()
        panel.update()
    except Exception:
        traceback.print_exc()
    wait(300)


def capture_failure(round_no: int) -> str:
    files = []
    try:
        sw = current_settings()
        if sw is None or not sw.isVisible():
            open_settings()
            wait(350)
        if sw is not None and sw.isVisible():
            path = os.path.join(FAIL_DIR, f"intra_round_{round_no:03d}_settings.png")
            if capture_widget(sw, path):
                files.append(path)
        path = os.path.join(FAIL_DIR, f"intra_round_{round_no:03d}_widget.png")
        if capture_widget(panel, path):
            files.append(path)
        if detail_visible():
            path = os.path.join(FAIL_DIR, f"intra_round_{round_no:03d}_detail.png")
            if capture_widget(panel._detail, path):
                files.append(path)
        if sw is not None and sw.isVisible():
            sw.close()
            wait(120)
    except Exception:
        traceback.print_exc()
    return ";".join(files)


def capture_normal(round_no: int) -> str:
    files = []
    try:
        open_settings()
        wait(450)
        sw = current_settings()
        if sw is not None and sw.isVisible():
            path = os.path.join(SHOTS_DIR, f"round_{round_no:03d}_settings.png")
            if capture_widget(sw, path):
                files.append(path)
        path = os.path.join(SHOTS_DIR, f"round_{round_no:03d}_widget.png")
        if capture_widget(panel, path):
            files.append(path)
        close_settings()
        wait(150)
    except Exception:
        traceback.print_exc()
    return ";".join(files)


def write_env() -> None:
    lines = []
    try:
        lines.append(f"OS: {platform.platform()}")
        lines.append(f"OS_VERSION: {platform.version()}")
        lines.append(f"PYTHON: {sys.version.split()[0]}")
        lines.append(f"APP_VERSION: {app_main.APP_VERSION}")
        screen = QGuiApplication.primaryScreen()
        if screen is not None:
            geo = screen.geometry()
            avail = screen.availableGeometry()
            lines.append(f"SCREEN_LOGICAL: {geo.width()}x{geo.height()}")
            lines.append(f"SCREEN_AVAILABLE: {avail.width()}x{avail.height()}")
            lines.append(f"DPR: {screen.devicePixelRatio()}")
        battery = reader.slot_item("battery")
        gpu = reader.slot_item("gpu")
        lines.append(f"BATTERY: value={getattr(battery, 'value', None)} "
                     f"status={getattr(battery, 'status', None)}")
        lines.append(f"GPU: value={getattr(gpu, 'value', None)} "
                     f"status={getattr(gpu, 'status', None)}")
    except Exception:
        lines.append("ENV_ERROR:")
        lines.append(traceback.format_exc())
    with open(os.path.join(TEST_DIR, "intra_env.txt"), "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")


def write_summary() -> None:
    with open(os.path.join(TEST_DIR, "summary_intra.csv"), "w",
              encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "轮次", "场景", "操作", "结果", "异常类型", "异常摘要", "traceback",
            "layout_mode", "debug_active", "lock_state", "slot_keys",
            "settings_visible", "detail_visible", "scroll_max", "截图文件",
        ])
        for row in round_rows:
            writer.writerow(row)


def write_log() -> None:
    with open(os.path.join(TEST_DIR, "intra_run_log.txt"), "w",
              encoding="utf-8") as handle:
        handle.write("\n".join(log_lines) + "\n")


def main() -> int:
    global app, reader, panel, stop_reason, consecutive_error

    os.makedirs(SHOTS_DIR, exist_ok=True)
    os.makedirs(FAIL_DIR, exist_ok=True)

    app = QApplication(sys.argv[:1])
    reader = SystemReader()
    reader.refresh()
    panel = app_main.VitalPanel(reader)
    panel.show()
    QTest.qWait(1200)

    log_lines.append(f"START {time.strftime('%Y-%m-%d %H:%M:%S')}")
    log_lines.append(f"PROJECT={PROJECT_DIR}")
    log_lines.append(f"APP_VERSION={app_main.APP_VERSION}")

    passed = 0
    failed = 0
    errored = 0
    shot_total = 0

    for round_no in range(1, 101):
        scenario_index = (round_no - 1) // 10
        scenario = SCENARIOS[scenario_index]
        cx = Ctx(round_no)
        result = "PASS"
        error_type = ""
        error_summary = ""
        error_trace = ""
        shots = ""
        state = {
            "layout_mode": "", "debug_active": -1, "lock_state": -1,
            "slot_keys": "", "settings_visible": -1,
            "detail_visible": -1, "scroll_max": -1,
        }
        try:
            ok, reason = SCENARIO_FUNCS[scenario_index](cx)
            if not ok:
                result = "FAIL"
                error_summary = reason
            state = snapshot_state(cx)
            if result == "FAIL":
                shots = capture_failure(round_no)
            elif round_no % 10 == 0:
                shots = capture_normal(round_no)
            if shots:
                shot_total += len(shots.split(";"))
        except Exception as exc:
            result = "ERROR"
            error_type = type(exc).__name__
            error_summary = str(exc)[:300].replace("\n", " ")
            error_trace = traceback.format_exc().replace("\n", " | ")
            log_lines.append(f"[{round_no:03d}] TRACEBACK:\n{traceback.format_exc()}")
            try:
                state = snapshot_state(cx)
                shots = capture_failure(round_no)
                if shots:
                    shot_total += len(shots.split(";"))
            except Exception:
                pass

        if result == "PASS":
            passed += 1
            consecutive_error = 0
        elif result == "FAIL":
            failed += 1
            consecutive_error = 0
        else:
            errored += 1
            consecutive_error += 1

        round_rows.append([
            round_no, scenario, " > ".join(cx.ops), result, error_type,
            error_summary, error_trace, state["layout_mode"],
            state["debug_active"], state["lock_state"], state["slot_keys"],
            state["settings_visible"], state["detail_visible"],
            state["scroll_max"], shots,
        ])
        log_lines.append(
            f"[{round_no:03d}] {scenario} {result} "
            f"ops={' > '.join(cx.ops)} | layout={state['layout_mode']} "
            f"debug={state['debug_active']} lock={state['lock_state']} "
            f"slots={state['slot_keys']} settings={state['settings_visible']} "
            f"detail={state['detail_visible']} scroll_max={state['scroll_max']}"
            + (f" | reason={error_summary}" if error_summary else "")
            + (f" | shots={shots}" if shots else "")
        )

        reset_round()

        if consecutive_error >= 5:
            stop_reason = f"连续 5 轮 ERROR，已在第 {round_no} 轮停止"
            log_lines.append(f"STOP_REASON: {stop_reason}")
            break

    try:
        reset_round()
    except Exception:
        traceback.print_exc()

    log_lines.append(
        f"END {time.strftime('%Y-%m-%d %H:%M:%S')} total={len(round_rows)} "
        f"PASS={passed} FAIL={failed} ERROR={errored} SHOTS={shot_total}")
    if stop_reason:
        log_lines.append(f"STOP_REASON={stop_reason}")
        with open(os.path.join(TEST_DIR, "STOP_REASON.txt"), "w",
                  encoding="utf-8") as handle:
            handle.write(stop_reason + "\n")

    write_env()
    write_summary()
    write_log()

    try:
        panel._timer.stop()
        panel._dock_timer.stop()
        panel._uninstall_win_event_hook()
        panel.close()
    except Exception:
        traceback.print_exc()
    QApplication.processEvents()
    print(f"INTRA_DONE total={len(round_rows)} PASS={passed} FAIL={failed} ERROR={errored}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        try:
            with open(os.path.join(TEST_DIR, "INTRA_CRASH.txt"), "w",
                      encoding="utf-8") as handle:
                handle.write(traceback.format_exc())
        except Exception:
            pass
        sys.exit(1)
