# -*- coding: utf-8 -*-
"""只读工作区对比：用 .git 对象库比较工作区与 HEAD，替代缺失的 git 命令。

不写任何项目文件，只打印结果。
"""

import hashlib
import os
import time
import zlib

REPO = r"d:\trae_projects\VitalsRing\VitalsRing"
GIT = os.path.join(REPO, ".git")
SKIP_DIRS = {".git", ".venv", "__pycache__"}


def read_obj(sha):
    path = os.path.join(GIT, "objects", sha[:2], sha[2:])
    data = zlib.decompress(open(path, "rb").read())
    header, _, body = data.partition(b"\0")
    return header, body


def read_ref():
    head = open(os.path.join(GIT, "HEAD"), "r", encoding="utf-8").read().strip()
    if head.startswith("ref: "):
        ref = head[5:]
        path = os.path.join(GIT, ref)
        if os.path.exists(path):
            return open(path, "r", encoding="utf-8").read().strip()
        packed = os.path.join(GIT, "packed-refs")
        if os.path.exists(packed):
            for line in open(packed, "r", encoding="utf-8"):
                if line.strip().endswith(ref):
                    return line.split()[0]
        return ""
    return head


def parse_tree(sha, prefix=""):
    _header, body = read_obj(sha)
    result = {}
    index = 0
    while index < len(body):
        space = body.index(b" ", index)
        nul = body.index(b"\0", space)
        mode = body[index:space]
        name = body[space + 1:nul].decode("utf-8", "replace")
        sha_hex = body[nul + 1:nul + 21].hex()
        index = nul + 21
        path = prefix + name
        if mode in (b"40000", b"040000"):
            result.update(parse_tree(sha_hex, path + "/"))
        else:
            result[path] = (mode.decode(), sha_hex)
    return result


def blob_sha(path):
    data = open(path, "rb").read()
    digest = hashlib.sha1()
    digest.update(b"blob %d\0" % len(data))
    digest.update(data)
    return digest.hexdigest()


def walk_worktree():
    files = {}
    for root, dirs, names in os.walk(REPO):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in names:
            full = os.path.join(root, name)
            rel = os.path.relpath(full, REPO).replace("\\", "/")
            files[rel] = full
    return files


def main():
    head = read_ref()
    print(f"HEAD={head}")
    _header, body = read_obj(head)
    tree_sha = None
    for line in body.split(b"\n"):
        if line.startswith(b"tree "):
            tree_sha = line.split()[1].decode()
            break
    tracked = parse_tree(tree_sha)
    worktree = walk_worktree()

    modified, deleted, untracked = [], [], []
    for rel, (_mode, sha) in sorted(tracked.items()):
        full = worktree.get(rel)
        if full is None:
            deleted.append(rel)
            continue
        if blob_sha(full) != sha:
            modified.append(rel)
    for rel in sorted(worktree):
        if rel not in tracked:
            untracked.append(rel)

    print("MODIFIED_TO_HEAD=" + (",".join(modified) if modified else "NONE"))
    print("DELETED_TO_HEAD=" + (",".join(deleted) if deleted else "NONE"))
    print("UNTRACKED=" + (",".join(untracked) if untracked else "NONE"))
    print("---SOURCE_MTIME---")
    for name in ("main.py", "readers.py", "settings_window.py", "README.md",
                 "requirements.txt", "启动.bat", ".gitignore"):
        full = os.path.join(REPO, name)
        if os.path.exists(full):
            stamp = time.strftime("%Y-%m-%d %H:%M:%S",
                                  time.localtime(os.path.getmtime(full)))
            print(f"{name}\t{stamp}")


if __name__ == "__main__":
    main()
