# -*- coding: utf-8 -*-
"""统一调度：备份配置 → 跑 100 轮进程内 → 跑 R01~R08 → 合并 → 恢复 → 清缓存。

不修改项目源码；所有产物写入 D:\\VitalsRing_Test_All。
"""

import csv
import json
import os
import shutil
import stat
import subprocess
import sys
import time
import traceback

PROJECT_DIR = r"d:\trae_projects\VitalsRing\VitalsRing"
TEST_DIR = r"D:\VitalsRing_Test_All"
SHOTS_DIR = os.path.join(TEST_DIR, "shots")
FAIL_DIR = os.path.join(TEST_DIR, "failures")
CONFIG_PATH = os.path.join(PROJECT_DIR, "vitalsring_config.json")
CONFIG_BACKUP = os.path.join(TEST_DIR, "config_before.json")

INTRA_SCRIPT = os.path.join(TEST_DIR, "intra_100.py")
WORKER_SCRIPT = os.path.join(TEST_DIR, "restart_worker.py")

INTRA_TIMEOUT = 1200
WORKER_TIMEOUT = 30

ROUND_TITLES = {
    "R01": "设置锁保留",
    "R02": "解锁恢复默认",
    "R03": "设置窗口打开时关闭",
    "R04": "调试模式关闭复位",
    "R05": "大面板模式持久化",
    "R06": "槽位配置持久化",
    "R07": "配置文件损坏回退",
    "R08": "配置文件只读",
}

DEFAULT_SLOTS = ["cpu", "gpu", "mem", "disk_c", "gear"]
LOCKED_BASELINE = {
    "layout_mode": "widget",
    "show_ticks": True,
    "use_icon_style": False,
    "icon_style": "line",
    "slot_keys": list(DEFAULT_SLOTS),
    "lock_state": True,
}
UNLOCKED_BASELINE = {
    "layout_mode": "widget",
    "show_ticks": False,
    "use_icon_style": True,
    "icon_style": "color",
    "slot_keys": list(DEFAULT_SLOTS),
    "lock_state": False,
}

log_lines = []


def log(text: str) -> None:
    log_lines.append(text)
    print(text)


def remove_config() -> None:
    for path in (CONFIG_PATH, CONFIG_PATH + ".tmp"):
        try:
            if os.path.exists(path):
                os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
                os.remove(path)
        except Exception:
            traceback.print_exc()


def write_config(payload) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def run_process(args, timeout, stdout_path):
    """统一子进程入口：超时/异常都转成状态字符串，不重试。"""
    started = time.time()
    try:
        with open(stdout_path, "w", encoding="utf-8") as handle:
            result = subprocess.run(
                args, cwd=PROJECT_DIR, stdout=handle, stderr=subprocess.STDOUT,
                timeout=timeout,
            )
        return {
            "status": "OK" if result.returncode == 0 else "EXIT",
            "returncode": result.returncode,
            "elapsed": round(time.time() - started, 1),
            "stdout": stdout_path,
        }
    except subprocess.TimeoutExpired:
        return {
            "status": "TIMEOUT",
            "returncode": None,
            "elapsed": round(time.time() - started, 1),
            "stdout": stdout_path,
        }
    except Exception:
        return {
            "status": "ERROR",
            "returncode": None,
            "elapsed": round(time.time() - started, 1),
            "stdout": stdout_path,
            "traceback": traceback.format_exc(),
        }


def read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return None


def tail_text(path, lines=6):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            content = handle.read().splitlines()
        return " || ".join(content[-lines:])
    except Exception:
        return ""


def timeout_payload(round_id: str, phase: str) -> dict:
    return {
        "阶段": "重启关闭",
        "轮次": round_id,
        "步骤": phase,
        "结果": "ERROR",
        "异常类型": "TimeoutExpired",
        "异常摘要": f"子进程超过 {WORKER_TIMEOUT} 秒未退出",
        "layout_mode": "",
        "lock_state": -1,
        "slot_keys": "",
        "debug_active": -1,
        "settings_visible": -1,
        "截图文件": "",
        "细节": {},
    }


def run_worker(round_id: str, phase: str):
    out_path = os.path.join(TEST_DIR, f"restart_{round_id}_{phase}.json")
    log_path = os.path.join(TEST_DIR, f"worker_{round_id}_{phase}_stdout.txt")
    result = run_process(
        [sys.executable, WORKER_SCRIPT, "--round", round_id, "--phase", phase],
        WORKER_TIMEOUT, log_path,
    )
    if result["status"] == "TIMEOUT":
        payload = timeout_payload(round_id, phase)
        with open(out_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
        return payload, result
    payload = read_json(out_path)
    if payload is None:
        payload = {
            "阶段": "重启关闭", "轮次": round_id, "步骤": phase,
            "结果": "ERROR", "异常类型": "MissingJSON",
            "异常摘要": "worker 未生成 JSON；"
                        + tail_text(log_path, 3),
            "layout_mode": "", "lock_state": -1, "slot_keys": "",
            "debug_active": -1, "settings_visible": -1,
            "截图文件": "", "细节": {},
        }
        with open(out_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
    return payload, result


def run_intra():
    log_path = os.path.join(TEST_DIR, "intra_stdout.txt")
    result = run_process([sys.executable, INTRA_SCRIPT], INTRA_TIMEOUT, log_path)
    log(f"INTRA status={result['status']} rc={result['returncode']} "
        f"elapsed={result['elapsed']}s")
    return result


def run_restart_rounds():
    payloads = []
    for round_id in ["R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08"]:
        # 每轮开始前把配置恢复到该轮需要的初始状态，避免上一轮残留污染
        remove_config()
        if round_id == "R02":
            write_config(LOCKED_BASELINE)
        elif round_id == "R07":
            with open(CONFIG_PATH, "wb") as handle:
                handle.write(b"\x00\xff{{{ this is not json \x00")
        elif round_id == "R08":
            write_config(UNLOCKED_BASELINE)

        phases = ["setup", "verify"] if round_id in ("R01", "R02", "R03",
                                                     "R04", "R05", "R06") else ["verify"]
        if round_id == "R08":
            try:
                os.chmod(CONFIG_PATH, stat.S_IREAD)
            except Exception:
                traceback.print_exc()

        for phase in phases:
            payload, result = run_worker(round_id, phase)
            payloads.append(payload)
            log(f"{round_id} {phase} {payload['结果']} "
                f"proc={result['status']} elapsed={result['elapsed']}s"
                + (f" | {payload['异常摘要']}" if payload["异常摘要"] else ""))

        if round_id == "R08":
            try:
                if os.path.exists(CONFIG_PATH):
                    os.chmod(CONFIG_PATH, stat.S_IWRITE | stat.S_IREAD)
            except Exception:
                traceback.print_exc()
    return payloads


def merge(payloads):
    rows = []
    intra_path = os.path.join(TEST_DIR, "summary_intra.csv")
    if os.path.exists(intra_path):
        with open(intra_path, "r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for item in reader:
                rows.append([
                    "进程内", item.get("轮次", ""), item.get("场景", ""),
                    item.get("结果", ""), item.get("异常类型", ""),
                    item.get("异常摘要", ""), item.get("截图文件", ""),
                ])
    for payload in payloads:
        rows.append([
            "重启关闭", payload.get("轮次", ""),
            ROUND_TITLES.get(payload.get("轮次", ""), ""),
            payload.get("结果", ""), payload.get("异常类型", ""),
            payload.get("异常摘要", ""), payload.get("截图文件", ""),
        ])
    out_path = os.path.join(TEST_DIR, "summary_all.csv")
    with open(out_path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["阶段", "轮次", "场景", "结果", "异常类型",
                         "异常摘要", "截图文件"])
        for row in rows:
            writer.writerow(row)
    return rows


def build_verdict_candidates(rows):
    """给识图阶段挑图：异常优先，其次每类场景第一张，再补重启 verify。"""
    candidates = []
    seen = set()

    def add(stage, round_no, scene, result, shot, expected, action):
        if not shot or shot in seen:
            return
        if not os.path.exists(shot):
            return
        seen.add(shot)
        candidates.append({
            "阶段": stage, "轮次": str(round_no), "场景": scene,
            "结果": result, "截图文件": shot,
            "操作": action, "预期": expected,
        })

    for row in rows:
        if row[3] in ("FAIL", "ERROR") and row[6]:
            for shot in row[6].split(";"):
                add(row[0], row[1], row[2], row[3], shot.strip(),
                    "该轮操作不产生异常、界面保持可交互",
                    "按 summary_all.csv 该轮异常路径执行")

    if len(candidates) < 20:
        for round_no in range(10, 101, 10):
            shot = os.path.join(SHOTS_DIR, f"round_{round_no:03d}_settings.png")
            scene = ""
            for row in rows:
                if row[0] == "进程内" and str(row[1]) == str(round_no):
                    scene = row[2]
                    break
            add("进程内", round_no, scene, "PASS", shot,
                "设置窗口完整显示、控件无错位/空白/重影",
                "打开设置窗口并截图")

    if len(candidates) < 20:
        for round_id in ["R01", "R02", "R03", "R04", "R05", "R06", "R07", "R08"]:
            shot = os.path.join(SHOTS_DIR, f"{round_id}_verify.png")
            add("重启关闭", round_id, ROUND_TITLES[round_id], "PASS", shot,
                "重启后配置/界面符合该轮预期", "verify 阶段启动并截图")

    return candidates[:20]


def restore_config():
    if os.path.exists(CONFIG_BACKUP):
        try:
            os.chmod(CONFIG_PATH, stat.S_IWRITE | stat.S_IREAD) \
                if os.path.exists(CONFIG_PATH) else None
            shutil.copy2(CONFIG_BACKUP, CONFIG_PATH)
            log("CONFIG_RESTORED=COPIED_BACK")
        except Exception:
            log("CONFIG_RESTORED=FAILED")
            traceback.print_exc()
    else:
        remove_config()
        log("CONFIG_RESTORED=DELETED_TEST_CONFIG")


def clean_cache():
    removed_dirs = 0
    removed_files = 0
    for root, dirs, files in os.walk(PROJECT_DIR):
        if ".venv" in root.split(os.sep):
            continue
        if os.path.basename(root) == "__pycache__":
            try:
                shutil.rmtree(root, ignore_errors=True)
                removed_dirs += 1
            except Exception:
                traceback.print_exc()
            continue
        for name in files:
            if name.endswith(".pyc"):
                try:
                    os.remove(os.path.join(root, name))
                    removed_files += 1
                except Exception:
                    traceback.print_exc()
    log(f"CACHE_CLEANED dirs={removed_dirs} pyc={removed_files}")


def write_log():
    with open(os.path.join(TEST_DIR, "run_log.txt"), "w", encoding="utf-8") as handle:
        handle.write("\n".join(log_lines) + "\n")


def main() -> int:
    os.makedirs(SHOTS_DIR, exist_ok=True)
    os.makedirs(FAIL_DIR, exist_ok=True)
    started = time.strftime("%Y-%m-%d %H:%M:%S")
    log(f"START {started}")
    log(f"PROJECT={PROJECT_DIR}")
    log(f"PYTHON={sys.executable}")

    if os.path.exists(CONFIG_PATH):
        shutil.copy2(CONFIG_PATH, CONFIG_BACKUP)
        log("CONFIG_BEFORE=EXISTS")
    else:
        log("CONFIG_BEFORE=MISSING")

    intra_result = run_intra()
    if intra_result["status"] != "OK":
        log(f"INTRA_TAIL={tail_text(intra_result['stdout'])}")

    payloads = run_restart_rounds()
    rows = merge(payloads)
    candidates = build_verdict_candidates(rows)
    with open(os.path.join(TEST_DIR, "verdict_candidates.json"), "w",
              encoding="utf-8") as handle:
        json.dump(candidates, handle, ensure_ascii=False, indent=2)

    restore_config()
    clean_cache()

    total = len(rows)
    intra_rows = [r for r in rows if r[0] == "进程内"]
    restart_rows = [r for r in rows if r[0] == "重启关闭"]
    log(f"SUMMARY total={total} intra={len(intra_rows)} restart_phases={len(restart_rows)}")
    log(f"END {time.strftime('%Y-%m-%d %H:%M:%S')}")
    write_log()
    print(f"ALL_DONE rows={total} candidates={len(candidates)}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        try:
            write_log()
        except Exception:
            pass
        sys.exit(1)
