# -*- coding: utf-8 -*-
"""VitalsRing 关闭/重启专项 worker：每次只跑一个阶段（setup / verify）后退出。

子进程本身即代表一次“重新启动”，由 run_all.py 依次拉起。
不移动真实鼠标/键盘；截图走 QScreen；异常只记录，不重试。
"""

import argparse
import json
import os
import shutil
import sys
import time
import traceback

PROJECT_DIR = r"d:\trae_projects\VitalsRing\VitalsRing"
TEST_DIR = r"D:\VitalsRing_Test_All"
SHOTS_DIR = os.path.join(TEST_DIR, "shots")
FAIL_DIR = os.path.join(TEST_DIR, "failures")

sys.path.insert(0, PROJECT_DIR)
os.chdir(PROJECT_DIR)

from PyQt6.QtCore import QPoint, QTimer
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import QApplication

import main as app_main
from readers import SystemReader

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

TITLES = {
    "R01": "设置锁保留",
    "R02": "解锁恢复默认",
    "R03": "设置窗口打开时关闭",
    "R04": "调试模式关闭复位",
    "R05": "大面板模式持久化",
    "R06": "槽位配置持久化",
    "R07": "配置文件损坏回退",
    "R08": "配置文件只读",
}

app = None
reader = None
panel = None


def wait(ms: int) -> None:
    if ms and ms > 0:
        QTest.qWait(int(ms))
    else:
        QApplication.processEvents()


def current_settings():
    return getattr(panel, "_settings", None) if panel is not None else None


def open_settings() -> None:
    panel._open_settings()
    QApplication.processEvents()


def close_settings() -> None:
    sw = current_settings()
    if sw is not None and sw.isVisible():
        sw.close()
        QApplication.processEvents()


def capture_widget(widget, path: str):
    try:
        screen = widget.screen() or QGuiApplication.primaryScreen()
        if screen is None:
            raise RuntimeError("no screen")
        full = screen.grabWindow(0)
        if full.isNull():
            raise RuntimeError("grab null")
        dpr = float(full.devicePixelRatio()) or 1.0
        geo = screen.geometry()
        top_left = widget.mapToGlobal(QPoint(0, 0))
        rx = int(round((top_left.x() - geo.x()) * dpr))
        ry = int(round((top_left.y() - geo.y()) * dpr))
        rw = max(1, int(round(widget.width() * dpr)))
        rh = max(1, int(round(widget.height() * dpr)))
        pix = full.copy(rx, ry, rw, rh)
        if pix.isNull():
            raise RuntimeError("crop null")
        pix.save(path, "PNG")
        return path
    except Exception:
        try:
            widget.grab().save(path, "PNG")
            return path
        except Exception:
            return None


def capture_screen(path: str):
    try:
        screen = QGuiApplication.primaryScreen()
        full = screen.grabWindow(0)
        full.save(path, "PNG")
        return path
    except Exception:
        return None


def click_lock(sw, prompt_path: str):
    """点击锁按钮；若因写盘失败弹出模态提示，定时器负责截图并关闭它。

    注意：QMessageBox.warning 会阻塞在嵌套事件循环里，必须在进入前布好
    定时器，否则 worker 会一直卡到 30 秒超时。
    """
    state = {"prompt_visible": False, "prompt_shot": ""}

    def handle_modal():
        try:
            modal = QApplication.activeModalWidget()
            if modal is not None:
                state["prompt_visible"] = True
                if prompt_path and not state["prompt_shot"]:
                    state["prompt_shot"] = capture_screen(prompt_path) or ""
                modal.close()
                # close() 之后仍活着就强制收掉，避免 worker 卡在嵌套事件循环
                try:
                    if modal.isVisible():
                        modal.hide()
                        modal.done(0)
                except Exception:
                    pass
        except Exception:
            traceback.print_exc()

    QTimer.singleShot(600, handle_modal)
    QTimer.singleShot(1500, handle_modal)
    sw._on_lock_clicked()
    wait(150)
    # 兜底：异常路径下模态框可能还活着，再确认一次并关掉，避免卡死
    try:
        modal = QApplication.activeModalWidget()
        if modal is not None:
            state["prompt_visible"] = True
            modal.close()
    except Exception:
        traceback.print_exc()
    return state


def state_of():
    sw = current_settings()
    try:
        settings_visible = bool(sw is not None and sw.isVisible())
    except Exception:
        settings_visible = False
    try:
        slots = "|".join(panel.slot_keys())
    except Exception:
        slots = ""
    return {
        "layout_mode": panel.layout_mode(),
        "lock_state": int(bool(panel.settings_locked())),
        "slot_keys": slots,
        "debug_active": int(bool(getattr(reader, "debug_active", False))),
        "settings_visible": int(settings_visible),
    }


# ------------------------------------------------------------------ 各轮阶段

def r01_setup():
    open_settings()
    wait(400)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建", {}
    lock_info = click_lock(sw, "")
    sw._show_ticks_check.setChecked(True)
    wait(300)
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R01_setup.png"))
    sw.close()
    wait(150)
    ok = panel.settings_locked() and panel.show_ticks_enabled()
    reason = "" if ok else "锁或刻度状态未生效"
    return ok, reason, {"shot": shot, "prompt_visible": lock_info["prompt_visible"]}


def r01_verify():
    shot_path = os.path.join(SHOTS_DIR, "R01_verify.png")
    ok_lock = panel.settings_locked()
    ok_ticks = panel.show_ticks_enabled()
    open_settings()
    wait(450)
    sw = current_settings()
    shot = capture_widget(sw, shot_path) if sw is not None else ""
    close_settings()
    wait(120)
    ok = ok_lock and ok_ticks
    detail = {"locked": int(ok_lock), "show_ticks": int(ok_ticks), "shot": shot}
    reason = "" if ok else "重启后锁状态或刻度配置未保留"
    return ok, reason, detail


def r02_setup():
    open_settings()
    wait(400)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建", {}
    info = click_lock(sw, "")
    wait(250)
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R02_setup.png"))
    sw.close()
    wait(150)
    ok = not panel.settings_locked()
    return ok, "" if ok else "解锁后 lock_state 仍为 True", {
        "prompt_visible": info["prompt_visible"], "shot": shot}


def r02_verify():
    ok_widget = panel.layout_mode() == "widget"
    ok_ticks = not panel.show_ticks_enabled()
    ok_icon = panel.icon_style() == "color" and panel.use_icon_style_enabled()
    ok_slots = panel.slot_keys() == panel.default_slot_keys()
    ok_lock = not panel.settings_locked()
    open_settings()
    wait(450)
    sw = current_settings()
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R02_verify.png")) if sw else ""
    close_settings()
    wait(120)
    ok = all((ok_widget, ok_ticks, ok_icon, ok_slots, ok_lock))
    detail = {
        "widget_mode": int(ok_widget), "ticks_off": int(ok_ticks),
        "icon_default": int(ok_icon), "slots_default": int(ok_slots),
        "unlocked": int(ok_lock), "shot": shot,
    }
    return ok, "" if ok else "解锁后重启未恢复默认", detail


def r03_setup():
    open_settings()
    wait(300)
    sw = current_settings()
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R03_setup.png")) if sw else ""
    # 进程内关闭：模拟设置窗口打开时直接结束进程
    panel.close()
    wait(100)
    return True, "", {"shot": shot}


def r03_verify():
    visible = bool(panel.isVisible())
    sw = current_settings()
    settings_visible = bool(sw is not None and sw.isVisible())
    modal = QApplication.activeModalWidget() is not None
    shot = capture_widget(panel, os.path.join(SHOTS_DIR, "R03_verify.png"))
    ok = visible and not settings_visible and not modal
    detail = {"panel_visible": int(visible),
              "settings_visible": int(settings_visible),
              "modal_visible": int(modal), "shot": shot}
    return ok, "" if ok else "重启后主窗口不可见或残留设置窗口/模态框", detail


def r04_setup():
    open_settings()
    wait(400)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建", {}
    sw._debug_check.setChecked(True)
    wait(300)
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R04_setup.png"))
    sw.close()
    wait(200)
    ok = not reader.debug_active
    return ok, "" if ok else "关闭设置后调试模式未复位", {
        "debug_after_close": int(bool(reader.debug_active)), "shot": shot}


def r04_verify():
    # 先看主窗口定时器（打开设置会顺带 resume_refresh，先测才严格）
    ok_timer = bool(panel._timer.isActive())
    open_settings()
    wait(500)
    sw = current_settings()
    ok_debug = not reader.debug_active
    ok_values = not bool(getattr(reader, "debug_values", {}))
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R04_verify.png")) if sw else ""
    close_settings()
    wait(120)
    ok = ok_debug and ok_values and ok_timer
    detail = {"debug_active": int(reader.debug_active),
              "debug_values_empty": int(ok_values),
              "refresh_timer_active": int(ok_timer), "shot": shot}
    return ok, "" if ok else "重启后调试状态或刷新定时器未复位", detail


def r05_setup():
    panel.set_layout_mode("panel")
    wait(350)
    panel.set_settings_locked(True)
    wait(250)
    shot = capture_widget(panel, os.path.join(SHOTS_DIR, "R05_setup.png"))
    ok = panel.layout_mode() == "panel" and panel.settings_locked()
    return ok, "" if ok else "大面板模式或锁定未生效", {"shot": shot}


def r05_verify():
    ok = panel.layout_mode() == "panel"
    shot = capture_widget(panel, os.path.join(SHOTS_DIR, "R05_verify.png"))
    return ok, "" if ok else "重启后未保持大面板模式", {
        "layout_mode": panel.layout_mode(), "shot": shot}


def r06_setup():
    target = ["cpu", "gpu", "disk_total", "battery", "gear"]
    ok_slots = panel.set_slot_config(target)
    wait(250)
    panel.set_settings_locked(True)
    wait(200)
    open_settings()
    wait(400)
    sw = current_settings()
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R06_setup.png")) if sw else ""
    close_settings()
    wait(120)
    ok = bool(ok_slots) and panel.slot_keys() == target and panel.settings_locked()
    return ok, "" if ok else "槽位修改或锁定未生效", {
        "slots": "|".join(panel.slot_keys()), "shot": shot}


def r06_verify():
    expected = ["cpu", "gpu", "disk_total", "battery", "gear"]
    ok_slots = panel.slot_keys() == expected
    open_settings()
    wait(450)
    sw = current_settings()
    combos_ok = False
    if sw is not None:
        try:
            combos_ok = all(combo.count() > 0 and combo.currentData() is not None
                            for combo in sw._slot_combos)
        except Exception:
            combos_ok = False
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R06_verify.png")) if sw else ""
    close_settings()
    wait(120)
    ok = ok_slots and combos_ok
    detail = {"slots": "|".join(panel.slot_keys()),
              "slots_preserved": int(ok_slots),
              "combos_no_blank": int(combos_ok), "shot": shot}
    return ok, "" if ok else "重启后槽位未保留或下拉出现空白", detail


def r07_verify():
    ok_widget = panel.layout_mode() == "widget"
    ok_ticks = not panel.show_ticks_enabled()
    ok_icon = panel.icon_style() == "color" and panel.use_icon_style_enabled()
    ok_slots = panel.slot_keys() == panel.default_slot_keys()
    ok_lock = not panel.settings_locked()
    modal = QApplication.activeModalWidget() is not None
    shot = capture_widget(panel, os.path.join(SHOTS_DIR, "R07_verify.png"))
    ok = all((ok_widget, ok_ticks, ok_icon, ok_slots, ok_lock)) and not modal
    detail = {
        "widget_mode": int(ok_widget), "ticks_off": int(ok_ticks),
        "icon_default": int(ok_icon), "slots_default": int(ok_slots),
        "unlocked": int(ok_lock), "modal_visible": int(modal), "shot": shot,
    }
    return ok, "" if ok else "损坏配置未回退默认或出现模态异常", detail


def r08_verify():
    open_settings()
    wait(450)
    sw = current_settings()
    if sw is None:
        return False, "设置窗口对象未创建", {}
    prompt_path = os.path.join(FAIL_DIR, "R08_prompt.png")
    info = click_lock(sw, prompt_path)
    wait(200)
    shot = capture_widget(sw, os.path.join(SHOTS_DIR, "R08_verify.png"))
    close_settings()
    wait(120)
    # 本轮不判死：只记录现象
    detail = {
        "prompt_visible": int(info["prompt_visible"]),
        "prompt_shot": info["prompt_shot"],
        "lock_state": int(bool(panel.settings_locked())),
        "shot": shot,
        "note": "只读配置下锁按钮的可见提示现象记录，不做通过/失败判定",
    }
    return True, "", detail


PHASES = {
    ("R01", "setup"): r01_setup,
    ("R01", "verify"): r01_verify,
    ("R02", "setup"): r02_setup,
    ("R02", "verify"): r02_verify,
    ("R03", "setup"): r03_setup,
    ("R03", "verify"): r03_verify,
    ("R04", "setup"): r04_setup,
    ("R04", "verify"): r04_verify,
    ("R05", "setup"): r05_setup,
    ("R05", "verify"): r05_verify,
    ("R06", "setup"): r06_setup,
    ("R06", "verify"): r06_verify,
    ("R07", "verify"): r07_verify,
    ("R08", "verify"): r08_verify,
}


def main() -> int:
    global app, reader, panel

    parser = argparse.ArgumentParser()
    parser.add_argument("--round", required=True)
    parser.add_argument("--phase", required=True)
    args = parser.parse_args()

    round_id = args.round
    phase = args.phase
    payload = {
        "阶段": "重启关闭",
        "轮次": round_id,
        "步骤": phase,
        "结果": "ERROR",
        "异常类型": "",
        "异常摘要": "",
        "layout_mode": "",
        "lock_state": -1,
        "slot_keys": "",
        "debug_active": -1,
        "settings_visible": -1,
        "截图文件": "",
    }
    extra = {}
    try:
        app = QApplication(sys.argv[:1])
        reader = SystemReader()
        reader.refresh()
        panel = app_main.VitalPanel(reader)
        panel.show()
        QTest.qWait(1200)

        func = PHASES.get((round_id, phase))
        if func is None:
            raise RuntimeError(f"未知轮次/阶段: {round_id} {phase}")
        ok, reason, extra = func()
        payload["结果"] = "PASS" if ok else "FAIL"
        payload["异常摘要"] = "" if ok else reason
    except Exception as exc:
        payload["结果"] = "ERROR"
        payload["异常类型"] = type(exc).__name__
        payload["异常摘要"] = str(exc)[:300].replace("\n", " ")
        extra = {"traceback": traceback.format_exc()}

    if panel is not None:
        try:
            payload["layout_mode"] = panel.layout_mode()
            payload["lock_state"] = int(bool(panel.settings_locked()))
            payload["slot_keys"] = "|".join(panel.slot_keys())
            payload["debug_active"] = int(bool(reader.debug_active))
            sw = current_settings()
            payload["settings_visible"] = int(bool(sw is not None and sw.isVisible()))
        except Exception:
            traceback.print_exc()

    shots = []
    if extra.get("shot"):
        shots.append(extra["shot"])
    if extra.get("prompt_shot"):
        shots.append(extra["prompt_shot"])
    payload["截图文件"] = ";".join(shots)

    # 失败/异常的截图复制到 failures，便于合并阶段统一取用
    if payload["结果"] != "PASS":
        for shot in list(shots):
            try:
                if shot and os.path.exists(shot):
                    target = os.path.join(
                        FAIL_DIR, f"{round_id}_{phase}_" + os.path.basename(shot))
                    if os.path.normcase(shot) != os.path.normcase(target):
                        shutil.copy2(shot, target)
                        payload["截图文件"] = payload["截图文件"].replace(shot, target)
            except Exception:
                traceback.print_exc()

    payload["细节"] = extra
    out_path = os.path.join(TEST_DIR, f"restart_{round_id}_{phase}.json")
    with open(out_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)

    try:
        if panel is not None:
            panel._timer.stop()
            panel._dock_timer.stop()
            panel._uninstall_win_event_hook()
            panel.close()
    except Exception:
        traceback.print_exc()
    QApplication.processEvents()
    print(f"WORKER_DONE {round_id} {phase} {payload['结果']}")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(1)
