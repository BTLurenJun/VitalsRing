# -*- coding: utf-8 -*-
import os
import sys
import platform
import traceback

OUT = r"D:\VitalsRing_Test_A"
SHOTS = os.path.join(OUT, "shots")
PROJECT = r"d:\trae_projects\VitalsRing\VitalsRing"

os.makedirs(SHOTS, exist_ok=True)
_log = open(os.path.join(OUT, "run_log.txt"), "w", encoding="utf-8")
sys.stdout = _log
sys.stderr = _log

sys.path.insert(0, PROJECT)

from PyQt6.QtWidgets import QApplication
from PyQt6.QtTest import QTest
import main  # noqa: E402

app = QApplication(sys.argv)
screen = app.primaryScreen()


def log(msg):
    print(msg, flush=True)


def wait(ms):
    QTest.qWait(ms)


def save_screen(name, x, y, w, h):
    x = max(0, int(x))
    y = max(0, int(y))
    w = min(screen.geometry().width() - x, int(w))
    h = min(screen.geometry().height() - y, int(h))
    pix = screen.grabWindow(0, x, y, w, h)
    pix.save(os.path.join(SHOTS, name), "PNG")
    log("[SHOT] %s %dx%d" % (name, w, h))


def save_widget(name, widget):
    widget.raise_()
    widget.activateWindow()
    wait(150)
    widget.grab().save(os.path.join(SHOTS, name), "PNG")
    log("[SHOT] %s widget" % name)


def panel_region():
    g = panel.frameGeometry()
    x = max(0, g.left() - 20)
    y = max(0, g.top() - 20)
    w = min(screen.geometry().width() - x, g.width() + 40)
    h = min(screen.geometry().height() - y, g.height() + 60)
    return x, y, w, h


def save_panel(name):
    x, y, w, h = panel_region()
    save_screen(name, x, y, w, h)


def save_settings_bottomleft(name, sw):
    sw.raise_()
    sw.activateWindow()
    wait(150)
    g = sw.frameGeometry()
    x = max(0, g.left() - 20)
    y = max(0, g.bottom() - 120)
    w = min(screen.geometry().width() - x, 300)
    h = min(screen.geometry().height() - y, 180)
    save_screen(name, x, y, w, h)


def write_env():
    with open(os.path.join(OUT, "env.txt"), "w", encoding="utf-8") as f:
        f.write("OS: %s\n" % platform.platform())
        f.write("Screen: %dx%d\n" % (screen.geometry().width(), screen.geometry().height()))
        f.write("DPR: %.3f\n" % screen.devicePixelRatio())
        f.write("VitalsRing: %s\n" % main.APP_VERSION)
        f.write("Battery: 由程序显示\n")
        f.write("GPU: 由程序显示\n")
        f.write("Taskbar autohide: 未知\n")


def write_cases():
    rows = [
        ("A01", "启动程序并等待吸附", "挂件出现且版本0.10.07.21，贴任务栏左侧", "A01_before.png;A01_after.png"),
        ("A02", "打开设置窗口", "设置窗口在屏幕左下角贴左边缘，底边在任务栏上方；调试模式关闭；标题栏正常", "A02_before.png;A02_after.png;A02_placement.png"),
        ("A03", "打开调试模式", "调试卡展开，两个按钮文字完整可见，无滚动条", "A03_before.png;A03_after.png"),
        ("A04", "快速连点调试开关10次", "最终状态一致，无卡死，按钮文字仍完整", "A04_after.png"),
        ("A05", "关闭设置再重新打开", "设置关闭后主窗口恢复；重新打开调试模式默认关闭", "A05_after.png;A05_reopen.png"),
        ("A06", "切大面板再切回挂件", "两种模式布局正常，版本号一致", "A06_panel.png;A06_widget.png"),
        ("A07", "打开详情窗口再关闭", "详情窗口按槽位显示，无空白/报错，关闭后挂件正常", "A07_detail.png;A07_after.png"),
    ]
    with open(os.path.join(OUT, "test_cases_A.csv"), "w", encoding="utf-8-sig", newline="") as f:
        f.write("轮次,操作,预期,截图文件名\n")
        for r in rows:
            f.write(",".join(r) + "\n")


def run():
    write_env()
    write_cases()
    log("[INFO] VitalsRing %s" % main.APP_VERSION)

    log("[STEP] A01 before")
    save_screen("A01_before.png", 0, screen.geometry().height() - 110, 320, 110)
    panel.show()
    wait(900)
    panel._dock_now()
    wait(600)
    log("[INFO] docked=%s status=%s" % (panel.is_docked(), panel.dock_status()))
    save_panel("A01_after.png")

    log("[STEP] A02 open settings")
    save_panel("A02_before.png")
    panel._open_settings()
    wait(900)
    sw = panel._settings
    save_widget("A02_after.png", sw)
    save_settings_bottomleft("A02_placement.png", sw)

    log("[STEP] A03 debug on")
    save_widget("A03_before.png", sw)
    sw._debug_check.setChecked(True)
    wait(700)
    save_widget("A03_after.png", sw)

    log("[STEP] A04 rapid toggles")
    for _ in range(10):
        sw._debug_check.setChecked(not sw._debug_check.isChecked())
        wait(40)
    wait(700)
    save_widget("A04_after.png", sw)

    log("[STEP] A05 close and reopen")
    sw.close()
    wait(700)
    save_panel("A05_after.png")
    panel._open_settings()
    wait(900)
    sw = panel._settings
    save_widget("A05_reopen.png", sw)

    log("[STEP] A06 panel mode")
    sw._mode_panel.setChecked(True)
    wait(900)
    sw.close()
    wait(600)
    save_panel("A06_panel.png")
    panel._open_settings()
    wait(900)
    sw = panel._settings
    sw._mode_widget.setChecked(True)
    wait(900)
    sw.close()
    wait(600)
    save_panel("A06_widget.png")

    log("[STEP] A07 detail")
    panel._toggle_detail()
    wait(600)
    if panel._detail is not None:
        save_widget("A07_detail.png", panel._detail)
    panel._toggle_detail()
    wait(500)
    save_panel("A07_after.png")

    log("[DONE] screenshots written")


reader = main.SystemReader()
panel = main.VitalPanel(reader)

try:
    run()
except Exception:
    traceback.print_exc()
finally:
    try:
        if panel._settings is not None:
            panel._settings.close()
        panel.close()
    except Exception:
        traceback.print_exc()
    try:
        _log.flush()
    except Exception:
        pass
    app.quit()